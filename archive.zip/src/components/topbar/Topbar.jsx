import "./topbar.css";
import { Search, Person, Chat, Notifications } from "@material-ui/icons";
import {Route, BrowserRouter as Router, Link } from 'react-router-dom';
import Profile from "../../pages/profile/Profile";

export default function Topbar() {


  
  return (
    <Router>
    <div className="topbarContainer">
      <div className="topbarLeft">
        <span className="logo">Lamasocial</span>
      </div>
      <div className="topbarCenter">
        <div className="searchbar">
          <Search className="searchIcon" />
          <input
            placeholder="Search for friend, post or video"
            className="searchInput"
          />
        </div>
      </div>
      <div className="topbarRight">
        <div className="topbarLinks">
          <span className="topbarLink">Homepage</span>
        </div>
        <div className="topbarIcons">
          <div className="topbarIconItem">
            <Person />
            <span className="topbarIconBadge">1</span>
          </div>
          <div className="topbarIconItem">
            <Chat />
            <span className="topbarIconBadge">2</span>
          </div>
          <div className="topbarIconItem">
            <Notifications />
            <span className="topbarIconBadge">1</span>
          </div>

          <Route component={Profile} path='../../pages/profile/Profile'/>
          

        </div> 
        <Link to="/profile">Profile</Link>
        </div>
    </div>
    </Router>
    

  );
}
